PICL 프로젝트 이미지

Figma에서 만든 WebP 이미지 17장을 아래 이름으로 정리해 이 폴더에 복사했습니다. 상세 페이지는 번호 순서로 이미지를 이어 보여주고, 스크롤하면 각 화면이 부드럽게 나타납니다.

01-cover.webp
02-background.webp
03-desk-research.webp
04-user-research-01.webp
05-user-research-02.webp
06-interview-01.webp
07-interview-02.webp
08-mvp-goal.webp
09-usability-test-01.webp
10-usability-test-02.webp
11-usability-test-03.webp
12-information-architecture.webp
13-design-system.webp
14-screen-design-01.webp
15-screen-design-02.webp
16-screen-design-03.webp
17-outro.webp

메인 프로젝트 카드 썸네일: 01-cover.webp
상세 페이지 상단 오른쪽 목업: picl-mockup.png
